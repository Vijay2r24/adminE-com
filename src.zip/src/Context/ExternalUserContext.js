import React, { createContext, useContext, useEffect, useState } from 'react';
import axios from 'axios';
import {getExternalByUserId} from "../Constants/apiRoutes"
// Create the context
const ExternalUserContext = createContext();

// Create a provider component
export const ExternalUserProvider = ({ children }) => {
  const [externalUser, setExternalUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const externalUserid = localStorage.getItem('externalUserid');

  useEffect(() => {
    const fetchExternalDetails = async () => {
      try {
        const response = await axios.get(`${getExternalByUserId}/${externalUserid}`);
        if (response.data?.StatusCode === "SUCCESS") {
          setExternalUser(response.data.user);
          console.log("Fetched User Data:", response.data.user);
        } else {
          setError("Unexpected response format or status code.");
          console.error("Unexpected response:", response.data);
        }
      } catch (err) {
        setError('Failed to fetch external details.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    if (externalUserid) {
      fetchExternalDetails();
    } else {
      setLoading(false);
    }
  }, [externalUserid]);

  return (
    <ExternalUserContext.Provider value={{ externalUser, loading, error }}>
      {children}
    </ExternalUserContext.Provider>
  );
};

// Custom hook to use context
export const useExternalUser = () => useContext(ExternalUserContext);

