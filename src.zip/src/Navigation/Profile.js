import React, { useState, useEffect, useContext, useRef } from "react";
import axios from "axios";
import { useNavigate, useLocation } from "react-router-dom";
import { UserContext } from "../Context/userContext";
import { Combobox } from "@headlessui/react";
import { CheckIcon, ChevronUpDownIcon } from "@heroicons/react/20/solid";
import {
  CREATEORUPDATE_USERS_API,
  GETALLROLESS_API,
  GETALLUSERSBYID_API,
  UpdatePassword, COUNTRIES_API,
} from "../Constants/apiRoutes";
import LoadingAnimation from "../Components/Loading/LoadingAnimation";
import { DataContext } from "../Context/DataContext";
import { toast, ToastContainer } from "react-toastify";
import { useParams } from "react-router-dom";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import { XMarkIcon } from "@heroicons/react/24/solid"; // Heroicons v2 syntax
import { FaPlus } from "react-icons/fa6";
import coverImage from "../assests/profile/image.jpg";
import { MdEmail } from "react-icons/md";
import { FaPhoneSquareAlt } from "react-icons/fa";
import { UserCircleIcon } from "@heroicons/react/solid";

const genderOptions = [
  { id: "M", name: "Male" },
  { id: "F", name: "Female" },
];

const Profile = () => {
  const [logindata, setLogindata] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { userDetails, setUserDeatails } = useContext(UserContext);
  const [roles, setRoles] = useState([]);
  const [countryMap, setCountryMap] = useState({});
  const [stateMap, setStateMap] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [cityMap, setCityMap] = useState({});
  const [query, setQuery] = useState("");
  const [error, setError] = useState("");
  const [stores, setStores] = useState([]);
  const [selectedStore, setSelectedStore] = useState("");
  const [countries, setCountries] = useState([]);
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);
  const [selectedCountry, setSelectedCountry] = useState("");

  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  // const [errors, setErrors] = useState({});
  const [imagePreview, setImagePreview] = useState("");
  const fileInputRef = useRef(null);
  const [profileImage, setProfileImage] = useState(null);
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState(""); // Success or error response message

  const UserId = localStorage.getItem("UserID");

  useEffect(() => {
    const userData = localStorage.getItem("userData");
    if (userData) {
      setLogindata(JSON.parse(userData));
    }
  }, []);
  useEffect(() => {
    const userData = localStorage.getItem("userData");
    if (userData) {
      const parsedData = JSON.parse(userData);
      setLogindata(parsedData);
      setFormData((prev) => ({
        ...prev,
        ...parsedData,
      }));

      // Set selectedCountry from CountryID if countries are already loaded
      if (countries.length > 0) {
        const matchedCountry = countries.find(
          (c) => c.CountryID === parsedData.CountryID
        );
        if (matchedCountry) {
          setSelectedCountry(matchedCountry);
        }
      }
    }
  }, [countries]);

  const [formData, setFormData] = useState(
    location.state?.userDetails || {
      // TenantID: 1,
      FirstName: "",
      LastName: "",
      Email: "",
      Password: "",
      PhoneNumber: "",

      RoleID: "",
      CountryID: "",

      Comments: "",
    }
  );

  const [selectedRole, setSelectedRole] = useState(formData.RoleID || "");
  const [editMode, setEditMode] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedGender, setSelectedGender] = useState(formData.Gender || "");
  const [isLoading, setIsLoading] = useState(false);
  const [formPasswordData, setFormPasswordData] = useState({
    userID: "", // Replace with dynamic user ID if needed
    oldPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormPasswordData({ ...formPasswordData, [name]: value });
  };

  // Handle modal close
  const handleClose = () => {
    setShowPasswordForm(false);
  };

  const fetchRoles = async () => {
    try {
      setIsLoading(true);
      const token = localStorage.getItem("token");
      const response = await fetch(GETALLROLESS_API, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      const data = await response.json();
      if (data.StatusCode === "SUCCESS") {
        setRoles(data.roles);
      }
    } catch (error) {
      console.error("Error fetching roles:", error);
    } finally {
      setIsLoading(false); // Hide loading animation
    }
  };
  const fetchCountries = async () => {
    const token = localStorage.getItem("token");
    try {
      const response = await axios.get(COUNTRIES_API, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      setCountries(response.data.data || []);
    } catch (error) {
      console.error("Error fetching countries:", error);
      toast.error("Failed to fetch countries.");
    }
  };
  useEffect(() => {
    fetchRoles();
    fetchCountries();
  }, []);

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const togglePasswordVisibility = () => {
    setShowPassword((prev) => !prev);
  };

  const handleGenderChange = (gender) => {
    setSelectedGender(gender);
    setFormData({
      ...formData,
      Gender: gender.id,
    });
  };

  // Form submit handler
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    let formErrors = {};

    // Validation
    if (!formPasswordData.oldPassword) {
      formErrors.oldPassword = "Old password is required.";
    }
    if (!formPasswordData.newPassword) {
      formErrors.newPassword = "New password is required.";
    }
    if (formPasswordData.confirmPassword !== formPasswordData.newPassword) {
      formErrors.confirmPassword = "Passwords do not match.";
    }

    setErrors(formErrors);

    // If no errors, make API call
    if (Object.keys(formErrors).length === 0) {
      setIsLoading(true);
      try {
        const response = await axios.post(UpdatePassword, {
          UserID: UserId,
          OldPassword: formPasswordData.oldPassword,
          NewPassword: formPasswordData.newPassword,
          ConfirmPassword: formPasswordData.confirmPassword,
        });

        // Toast success message
        toast.success("Password updated successfully!");
        setIsLoading(true);
        setShowPasswordForm(false);

        console.log("Response:", response.data);

        // Clear form fields
        setFormPasswordData({
          userID: UserId,
          oldPassword: "",
          newPassword: "",
          confirmPassword: "",
        });
        setErrors({});
      } catch (error) {
        // Toast error message
        const errorMessage =
          error.response?.data?.message || "Failed to update password.";
        toast.error(errorMessage);
        console.error("Error updating password:", errorMessage);
      } finally {
        setIsLoading(false);
      }
    }
  };

  const handleFormSubmit = async (event) => {
    event.preventDefault();
    const token = localStorage.getItem("token");

    try {
      const isEditMode = Boolean(formData.UserID);
      setIsLoading(true);

      const formDataToSend = { ...formData };

      if (isEditMode) {
        formDataToSend.UserID = formData.UserID; // Ensure UserID is sent for updates
      } else {
        formDataToSend.TenantID = 1;
      }

      formDataToSend.RoleID = selectedRole?.RoleID || "";
      formDataToSend.CountryID = selectedCountry?.CountryID || "";
      formDataToSend.IsInternal = true;

      const apiUrl = CREATEORUPDATE_USERS_API;
      const method = isEditMode ? "post" : "post"; // Use PUT for updates

      const response = await axios({
        method,
        url: apiUrl,
        data: formDataToSend,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.data.StatusCode === "SUCCESS") {
        toast.success(response.data.message);
        setTimeout(() => {
          navigate("/Profile");
        }, 5500);
      }
    } catch (error) {
      console.error("User submission failed:", error);
      toast.error(error.response?.data?.message || "An error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsEditing(false);
      setIsLoading(false);
    }, 500);
  };

  useEffect(() => {
    if (formData.RoleID && roles.length > 0) {
      const role = roles.find((r) => r.RoleID === formData.RoleID);
      if (role) {
        setSelectedRole(role);
      }
    }
  }, [formData.RoleID, roles]);
  const validateUserData = () => {
    const newErrors = {};
    if (!formData.StoreName) {
      newErrors.StoreNameError = "Store Name is required.";
    }

    if (!formData.RoleID) {
      newErrors.RoleIdError = "Role is required.";
    }
    if (!formData.FirstName) {
      newErrors.FirstNameError = "First Name is required.";
    }
    if (!formData.AddressLine1) {
      newErrors.AddressLine1Error = "Address Line 1 is required.";
    }
    if (!formData.Email) {
      newErrors.EmailError = "Email is required.";
    }
    if (!formData.CountryID) {
      newErrors.CountryIdError = "Country is required.";
    }
    if (!formData.Password) {
      newErrors.PasswordError = "Password is required.";
    }
    if (!formData.StateID) {
      newErrors.StateIdError = "State is required.";
    }
    if (!formData.PhoneNumber) {
      newErrors.PhoneNumberError = "Phone Number is required.";
    }
    if (!formData.CityID) {
      newErrors.CityIdError = "City is required.";
    }
    if (!formData.ZipCode) {
      newErrors.ZipCodeError = "Zip Code is required.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length > 0;
  };

  const handleRoleChange = (selectedRole) => {
    setSelectedRole(selectedRole);
    setFormData((prevFormData) => ({
      ...prevFormData,
      RoleID: selectedRole?.RoleID || "",
    }));
    setQuery(""); // Reset the search query after selection
  };

  // Function to open the modal
  const openModal = () => {
    setIsModalOpen(true);
  };

  // Function to close the modal
  const closeModal = () => {
    setIsModalOpen(false);
  };

  const handleUpdateButtonClick = () => {
    // Fetch user details when "Update" button is clicked
    setIsEditing(true); // Enable edit mode
  };

  const handleUpdatePasswordClick = () => {
    setIsEditing(false); // Exit editing mode
    setIsLoading(true); // Start loading

    // Simulate a short delay (e.g., fetching data or processing)
    setTimeout(() => {
      setShowPasswordForm(true); // Show the password form
      setIsLoading(false); // Stop loading
    }, 500);
  };

  const handleCountryChange = (selectedCountry) => {
    setSelectedCountry(selectedCountry);
    setFormData((prevFormData) => ({
      ...prevFormData,
      CountryID: selectedCountry?.CountryID || "",
    }));
  };
  return (
    <div className={`main-container`}>
      <div className="flex flex-col gap-4 sm:flex-row sm:justify-between sm:items-center">
        <h2 className="text-2xl font-semibold">Profile</h2>
      </div>

      <div className="mt-6">
        {/* User Details */}
        {logindata && (
          <>
            <div className="bg-white rounded-lg w-full h-auto border border-gray-200">
              {/* Cover Photo Section */}
              <div className="relative">
                {coverImage ? (
                  <img
                    src={coverImage}
                    alt="Cover Photo"
                    className="w-full h-48 object-cover"
                  />
                ) : (
                  <UserCircleIcon className="h-16 w-16 text-gray-400" />
                )}
              </div>

              {/* Profile Picture and Name Section */}
              <div className="flex items-center -mt-16 ml-6">
                <div className="relative w-40 h-40 rounded-full border-4 border-white">
                  <img
                    src="https://i.imgur.com/hczKIze.jpg"
                    alt={`${logindata.FirstName} ${logindata.LastName}`}
                    className="w-full h-full object-cover rounded-full transition-transform duration-200 ease-in-out transform hover:scale-105"
                    onClick={openModal} // Opens the modal
                  />

                  {isEditing && (
                    <button
                      className="absolute bottom-2 right-2 flex items-center justify-center"
                      style={{ width: "40px", height: "40px" }}
                    >
                      <div
                        className="bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center cursor-pointer border-2 border-white"
                        onClick={() =>
                          document.getElementById("profile-upload").click()
                        } // Triggers file input click
                      >
                        <FaPlus className="w-5 h-5" />
                      </div>

                      <input
                        id="profile-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                      // onChange={(e) => handleImageChange(e, "profile")} // Handles image upload
                      />
                    </button>
                  )}

                  {isModalOpen && (
                    <div
                      className="fixed inset-0 bg-gray-800 bg-opacity-50 flex justify-center items-center z-50"
                      onClick={closeModal} // Close modal when clicking outside
                    >
                      <div
                        className="relative bg-white p-4 rounded-lg"
                        onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside
                      >
                        <img
                          src="https://i.imgur.com/hczKIze.jpg"
                          alt={`${logindata.FirstName} ${logindata.LastName}`}
                          className="w-96 h-96 object-cover"
                        />
                        <button
                          className="absolute top-0 right-0 m-1 text-white bg-red-500 p-1 rounded-full"
                          onClick={closeModal} // Close modal when clicking the close button
                        >
                          <XMarkIcon className="w-6 h-6" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="ml-6 mt-2 flex flex-col items-start">
                <h1 className="text-2xl font-bold text-gray-800 mb-2 ml-6">
                  {logindata.FirstName} {logindata.LastName}
                </h1>
                <p className="flex items-center text-gray-600 text-sm md:text-lg mt-1 ml-0">
                  <MdEmail className="text-xl md:text-2xl text-blue-500 mr-3" />
                  {logindata.Email}
                </p>
                <p className="flex items-center text-gray-600 text-sm md:text-lg mt-1">
                  <FaPhoneSquareAlt className="text-xl md:text-2xl text-green-500 mr-3" />
                  {logindata.PhoneNumber}
                </p>

                <br />
              </div>
            </div>

            <div className="user-details">
              {!isEditing && (
                <div>
                  <div className="flex items-center space-x-4 mt-4">
                    <div></div>
                  </div>

                  <div className="bg-white rounded-lg w-full h-auto border border-gray-200">
                    {/* Buttons */}
                    <div className="flex flex-col sm:flex-row justify-end gap-4 mt-4 sm:mr-6 mr-2 sm:items-end items-center">
                      <button
                        onClick={handleUpdateButtonClick}
                        className="inline-flex justify-center rounded-md border border-transparent bg-[#632e0f] py-1.5 px-3 text-xs sm:text-sm font-medium text-white shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                      >
                        Update
                      </button>
                      <button
                        onClick={handleUpdatePasswordClick}
                        className="inline-flex justify-center rounded-md border border-transparent bg-[#632e0f] py-1.5 px-3 text-xs sm:text-sm font-medium text-white shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                      >
                        Update Password
                      </button>
                    </div>

                    {/* Profile Info */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 px-4 sm:px-10 pt-4 pb-4">

                      {/* Full Name */}
                      <div className="flex flex-wrap sm:flex-nowrap items-start sm:items-center">
                        <p className="text-xs font-semibold text-gray-500 min-w-[100px]">Full Name</p>
                        <span className="text-gray-800 mx-2">:</span>
                        <p className="break-words text-sm font-medium text-gray-700">
                          {logindata.FirstName} {logindata.LastName}
                        </p>
                      </div>

                      {/* Role */}
                      <div className="flex flex-wrap sm:flex-nowrap items-start sm:items-center">
                        <p className="text-xs font-semibold text-gray-500 min-w-[100px]">Role</p>
                        <span className="text-gray-800 mx-2">:</span>
                        <p className="break-words text-sm font-medium text-gray-700">
                          {selectedRole?.RoleName}
                        </p>
                      </div>

                      {/* Email */}
                      <div className="flex flex-wrap sm:flex-nowrap items-start sm:items-center">
                        <p className="text-xs font-semibold text-gray-500 min-w-[100px]">Email</p>
                        <span className="text-gray-800 mx-2">:</span>
                        <p className="break-words text-sm font-medium text-gray-700">
                          {logindata.Email}
                        </p>
                      </div>

                      {/* Phone */}
                      <div className="flex flex-wrap sm:flex-nowrap items-start sm:items-center">
                        <p className="text-xs font-semibold text-gray-500 min-w-[100px]">Phone Number</p>
                        <span className="text-gray-800 mx-2">:</span>
                        <p className="break-words text-sm font-medium text-gray-700">
                          {logindata?.PhoneNumber}
                        </p>
                      </div>

                      {/* Country */}
                      <div className="flex flex-wrap sm:flex-nowrap items-start sm:items-center">
                        <p className="text-xs font-semibold text-gray-500 min-w-[100px]">Country</p>
                        <span className="text-gray-800 mx-2">:</span>
                        <p className="break-words text-sm font-medium text-gray-700">
                          {logindata.CountryName}
                        </p>
                      </div>

                      {/* State */}
                      <div className="flex flex-wrap sm:flex-nowrap items-start sm:items-center mb-4">
                        <p className="text-xs font-semibold text-gray-500 min-w-[100px]">State</p>
                        <span className="text-gray-800 mx-2">:</span>
                        <p className="break-words text-sm font-medium text-gray-700">
                          {logindata?.StateName}
                        </p>
                      </div>
                    </div>
                  </div>


                </div>
              )}

              <ToastContainer />
              {isLoading && (
                <div className="fixed inset-0 flex items-center justify-center z-50 bg-opacity-50">
                  <LoadingAnimation />
                </div>
              )}
              {isEditing && (
                <form className="w-full">
                  <div className="flex items-center space-x-4 mt-4 relative">
                    {/* Modal for Image Preview */}
                    {isModalOpen && (
                      <div
                        className="fixed inset-0 bg-gray-800 bg-opacity-50 flex justify-center items-center z-50"
                        onClick={closeModal} // Close the modal when clicking outside
                      >
                        <div
                          className="relative bg-white p-4 rounded-lg"
                          onClick={(e) => e.stopPropagation()} // Prevent modal from closing when clicking inside
                        >
                          <img
                            src={logindata.ProfileImage}
                            alt={`${logindata.FirstName} ${logindata.LastName}`}
                            className="w-96 h-96 object-cover"
                          />
                          <button
                            className="absolute top-0 right-0 m-1 text-white bg-red-500 p-1 rounded-full"
                            onClick={closeModal}
                          >
                            <XMarkIcon className="w-6 h-6" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex justify-between items-center mb-6"></div>
                  <div className="grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-2 px-10 md:px-24 bg-white rounded-lg w-full h-auto border border-gray-200">
                    {/* First Name */}
                    <div className="flex items-center">
                      <div className="w-full ">
                        <label
                          htmlFor="FirstName"
                          className="block text-sm font-medium text-gray-700 mt-2"
                        >
                          First Name <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="FirstName"
                          name="FirstName"
                          value={formData.FirstName || ""}
                          onChange={handleFormChange}
                          required
                          className={`mt-2 mb-1 block w-full xl:w-3/4 rounded-md border  shadow-sm py-2 px-4  sm:text-sm ${!formData.FirstName && errors.FirstNameError
                            ? "border-red-400"
                            : "border-gray-400"
                            }`}
                        />
                        {!formData.FirstName && errors.FirstNameError && (
                          <p className="text-red-500 text-sm mt-1 ">
                            {errors.FirstNameError}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Last Name */}
                    <div>
                      <label
                        htmlFor="LastName"
                        className="block text-sm font-medium text-gray-700 mt-2"
                      >
                        Last Name
                      </label>
                      <input
                        type="text"
                        id="LastName"
                        name="LastName"
                        value={formData.LastName || ""}
                        onChange={handleFormChange}
                        required
                        className={`mt-2 mb-1 block w-full xl:w-3/4 rounded-md border shadow-sm py-2 px-4  sm:text-sm border-gray-400
                `}
                      />
                    </div>

                    {/* Email */}
                    <div>
                      <label
                        htmlFor="Email"
                        className="block text-sm font-medium text-gray-700"
                      >
                        Email <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        id="Email"
                        name="Email"
                        value={formData.Email || ""}
                        onChange={handleFormChange}
                        required
                        className={`mt-2 mb-1 block w-full xl:w-3/4 rounded-md border shadow-sm py-2 px-4  sm:text-sm ${!formData.Email && errors.EmailError
                          ? "border-red-400"
                          : "border-gray-400"
                          }`}
                      />
                      {!formData.Email && errors.EmailError && (
                        <p className="text-red-500 text-sm mt-1 ">
                          {errors.EmailError}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="w-full xl:w-3/4 ">
                        <label
                          htmlFor="Country"
                          className="block text-sm font-medium text-gray-700"
                        >
                          Country <span className="text-red-500">*</span>
                        </label>
                        <Combobox
                          as="div"
                          value={selectedCountry}
                          onChange={handleCountryChange}
                        >
                          <div className="relative">
                            <Combobox.Input
                              id="Country"
                              name="Country"
                              className={`block w-full rounded-md border  py-2 px-4 shadow-sm  sm:text-sm mt-2 mb-1 ${!formData.CountryID && errors.CountryIdError
                                ? "border-red-400"
                                : "border-gray-400"
                                }`}
                              onChange={(event) => setQuery(event.target.value)} // Set the query for filtering
                              displayValue={(country) =>
                                country?.CountryName || ""
                              } // Display selected country name
                            />
                            <Combobox.Button className="absolute inset-y-0 right-0 flex items-center rounded-r-md px-2 focus:outline-none">
                              <ChevronUpDownIcon
                                className="h-5 w-5 text-gray-400"
                                aria-hidden="true"
                              />
                            </Combobox.Button>

                            <Combobox.Options className="absolute z-10 mt-1 max-h-60 w-full xl:w-3/4 overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm">
                              {countries
                                .filter((country) =>
                                  country.CountryName.toLowerCase().includes(
                                    query.toLowerCase()
                                  )
                                )
                                .map((country) => (
                                  <Combobox.Option
                                    key={country.CountryID}
                                    value={country} // Pass the full country object to onChange
                                    className="group relative cursor-default select-none py-2 pl-3 pr-9 text-gray-900 hover:bg-indigo-600 hover:text-white"
                                  >
                                    <span className="block truncate font-normal group-data-[selected]:font-semibold">
                                      {country.CountryName}
                                    </span>
                                    <span className="absolute inset-y-0 right-0 hidden items-center pr-4 text-indigo-600 group-data-[selected]:flex group-data-[focus]:text-white">
                                      <CheckIcon
                                        className="h-5 w-5"
                                        aria-hidden="true"
                                      />
                                    </span>
                                  </Combobox.Option>
                                ))}
                            </Combobox.Options>
                          </div>
                        </Combobox>
                        {!formData.CountryID && errors.CountryIdError && (
                          <p className="text-red-500 text-sm mt-1 ">
                            {errors.CountryIdError}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Password */}
                    <div className=" xl:w-3/4">
                      <label
                        htmlFor="Password"
                        className="block text-sm font-medium text-gray-700"
                      >
                        Password <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <input
                          id="Password"
                          name="Password"
                          type={showPassword ? "text" : "password"}
                          value={formData.Password || ""}
                          onChange={handleFormChange}
                          className={`mt-2 mb-1 block w-full  rounded-md border shadow-sm py-2 px-4  sm:text-sm ${!formData.Password && errors.PasswordError
                            ? "border-red-400"
                            : "border-gray-400"
                            }`}
                        />
                        <span
                          className="absolute right-2 top-1/2 pb-1 transform -translate-y-1/2 cursor-pointer "
                          onClick={togglePasswordVisibility}
                        >
                          {showPassword ? (
                            <VisibilityOffIcon
                              fontSize="small"
                              className="opacity-75"
                            />
                          ) : (
                            <VisibilityIcon
                              fontSize="small"
                              className="opacity-75"
                            />
                          )}
                        </span>
                      </div>
                      {!formData.Password && errors.PasswordError && (
                        <p className="text-red-500 text-sm mt-1 ">
                          {errors.PasswordError}
                        </p>
                      )}
                    </div>

                    {/* Phone Number */}
                    <div>
                      <label
                        htmlFor="PhoneNumber"
                        className="block text-sm font-medium text-gray-700"
                      >
                        Phone Number <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="number"
                        id="PhoneNumber"
                        name="PhoneNumber"
                        value={formData.PhoneNumber || ""}
                        onChange={handleFormChange}
                        required
                        className={`mt-2 mb-1 block w-full xl:w-3/4 rounded-md border  shadow-sm py-2 px-4  sm:text-sm ${!formData.PhoneNumber && errors.PhoneNumberError
                          ? "border-red-400"
                          : "border-gray-400"
                          }`}
                      />
                      {!formData.PhoneNumber && errors.PhoneNumberError && (
                        <p className="text-red-500 text-sm mt-1 ">
                          {errors.PhoneNumberError}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center">
                      <div className="w-full">
                        <label
                          htmlFor="Region"
                          className="block text-sm font-medium text-gray-700 mt-2"
                        >
                          Region <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="Region"
                          name="Region"
                          value={formData.Region || ""}
                          onChange={handleFormChange}
                          required
                          className={`mt-2 mb-1 block w-full xl:w-3/4 rounded-md border shadow-sm py-2 px-4 sm:text-sm ${!formData.Region && errors.RegionError
                            ? "border-red-400"
                            : "border-gray-400"
                            }`}
                        />
                        {!formData.Region && errors.RegionError && (
                          <p className="text-red-500 text-sm mt-1">
                            {errors.RegionError}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center">
                      <div className="w-full">
                        <label
                          htmlFor="BusinessUnit"
                          className="block text-sm font-medium text-gray-700 mt-2"
                        >
                          Business Unit <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          id="BusinessUnit"
                          name="BusinessUnit"
                          value={formData.BusinessUnit || ""}
                          onChange={handleFormChange}
                          required
                          className={`mt-2 mb-1 block w-full xl:w-3/4 rounded-md border shadow-sm py-2 px-4 sm:text-sm ${!formData.BusinessUnit && errors.BusinessUnitError
                            ? "border-red-400"
                            : "border-gray-400"
                            }`}
                        />
                        {!formData.BusinessUnit && errors.BusinessUnitError && (
                          <p className="text-red-500 text-sm mt-1">
                            {errors.BusinessUnitError}
                          </p>
                        )}
                      </div>
                    </div>

                    <div></div>
                    <div className="mt-0 flex justify-end gap-4 mb-10">
                      <button
                        type="submit"
                        className="button-base save-btn"
                        onClick={handleFormSubmit}
                      >
                        {UserId !== "new" ? "Update Profile" : "Create User"}
                      </button>
                      <button
                        type="button"
                        onClick={handleCancel}
                        className="button-base save-btn"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </form>
              )}

              {/* Modal */}
              {showPasswordForm && (
                <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-75 z-50">
                  <div className="bg-white p-6 rounded-lg shadow-lg w-96 relative">
                    {/* Close Button */}
                    <button
                      onClick={handleClose}
                      className="absolute top-2 right-2 text-gray-500 hover:text-gray-700 text-xl font-bold"
                    >
                      &times;
                    </button>

                    {/* Modal Title */}
                    <h2 className="text-2xl font-semibold mb-4 text-gray-800">
                      Update Password
                    </h2>
                    <form onSubmit={handleSubmit}>
                      {/* Old Password */}
                      <div className="mb-4">
                        <label
                          htmlFor="oldPassword"
                          className="block text-sm font-medium text-gray-700"
                        >
                          Old Password <span className="text-red-500">*</span>
                        </label>
                        <div className="relative">
                          <input
                            id="oldPassword"
                            name="oldPassword"
                            type={showPassword ? "text" : "password"}
                            value={formPasswordData.oldPassword}
                            onChange={handleInputChange}
                            className={`mt-2 mb-1 block w-full rounded-md border py-2 px-4 sm:text-sm ${errors.oldPassword
                              ? "border-red-400"
                              : "border-gray-400"
                              }`}
                            placeholder="Enter old password"
                          />
                          <span
                            className="absolute right-2 top-1/2 transform -translate-y-1/2 cursor-pointer"
                            onClick={togglePasswordVisibility}
                          >
                            {showPassword ? (
                              <VisibilityOffIcon
                                fontSize="small"
                                className="opacity-75"
                              />
                            ) : (
                              <VisibilityIcon
                                fontSize="small"
                                className="opacity-75"
                              />
                            )}
                          </span>
                        </div>
                        {errors.oldPassword && (
                          <p className="text-red-500 text-sm mt-1">
                            {errors.oldPassword}
                          </p>
                        )}
                      </div>

                      {/* New Password */}
                      <div className="mb-4">
                        <label
                          htmlFor="newPassword"
                          className="block text-sm font-medium text-gray-700"
                        >
                          New Password <span className="text-red-500">*</span>
                        </label>
                        <input
                          id="newPassword"
                          name="newPassword"
                          type="password"
                          value={formPasswordData.newPassword}
                          onChange={handleInputChange}
                          className={`mt-2 mb-1 block w-full rounded-md border py-2 px-4 sm:text-sm ${errors.newPassword
                            ? "border-red-400"
                            : "border-gray-400"
                            }`}
                          placeholder="Enter new password"
                        />
                        {errors.newPassword && (
                          <p className="text-red-500 text-sm mt-1">
                            {errors.newPassword}
                          </p>
                        )}
                      </div>

                      {/* Confirm Password */}
                      <div className="mb-4">
                        <label
                          htmlFor="confirmPassword"
                          className="block text-sm font-medium text-gray-700"
                        >
                          Confirm Password{" "}
                          <span className="text-red-500">*</span>
                        </label>
                        <input
                          id="confirmPassword"
                          name="confirmPassword"
                          type="password"
                          value={formPasswordData.confirmPassword}
                          onChange={handleInputChange}
                          className={`mt-2 mb-1 block w-full rounded-md border py-2 px-4 sm:text-sm ${errors.confirmPassword
                            ? "border-red-400"
                            : "border-gray-400"
                            }`}
                          placeholder="Confirm new password"
                        />
                        {errors.confirmPassword && (
                          <p className="text-red-500 text-sm mt-1">
                            {errors.confirmPassword}
                          </p>
                        )}
                      </div>

                      {/* Submit Button */}
                      <button
                        type="submit"
                        className="w-full mb-6 mt-6 inline-flex justify-center rounded-md border border-transparent bg-[#632e0f] py-2 px-4 text-sm font-medium text-white shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                      >
                        Submit
                      </button>
                    </form>
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
export default Profile;
