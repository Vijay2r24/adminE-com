import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { FiMenu } from "react-icons/fi";
import { Menu } from "@headlessui/react";
import { useParams } from "react-router-dom";
import { ChevronDownIcon } from "@heroicons/react/20/solid";
import { useAuth } from "../Context/AuthContext";
import axios from "axios";
import {getExternalByUserId} from "../Constants/apiRoutes"
import { useExternalUser } from '../Context/ExternalUserContext';
const Navigation = () => {
  const navigate = useNavigate();
  const [logindata, setLogindata] = useState(null);
     const [error, setError] = useState(null);
      // const [externalData, setExternalData] = useState(null);
      const [loading, setLoading] = useState(false);
      const externalUserid = localStorage.getItem('externalUserid');
      const { externalData } = useExternalUser();

      
      

  const handleSignOut = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userData");
    navigate("/");
  };

  return (
    <header className="fixed top-0 left-0 w-full bg-white shadow-md flex items-center justify-between px-4 h-12 z-50">
      <div className="text-xl text-[#632e0f]">
      </div>

      <div className="flex items-center gap-4">
        <Menu as="div" className="relative">
          <Menu.Button className="flex items-center gap-2 hover:bg-[#8B4513]/10 rounded-lg px-2 py-1">
            <img
              src={
                logindata?.ProfileImage || "https://i.imgur.com/hczKIze.jpg"
              }
              alt="Profile"
              className="w-8 h-8 rounded-full"
            />
           <span className="hidden md:block text-sm font-medium text-gray-700">
       {externalData?.FirstName && externalData?.LastName && `${externalData.FirstName} (${externalData.LastName})`}
       </span>
            {/* <ChevronDownIcon className="w-5 h-5 text-gray-400" /> */}
          </Menu.Button>
        </Menu>
      </div>
    </header>
  );
};

export default Navigation;
