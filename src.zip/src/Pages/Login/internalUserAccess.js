import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const InternalUserPrompt = () => {
  const [showPopup, setShowPopup] = useState(false);
  const navigate = useNavigate();
  const { userId, documentId } = useParams(); // ✅ Get both params
   const [externalData, setExternalData] = useState(null);
  useEffect(() => {
    const userData = localStorage.getItem('userData');
  
    if (userData) {
      try {
        const parsedUser = JSON.parse(userData);
  
        // Ensure both values are of same type (number or string)
        if (String(parsedUser.UserID) === String(userId)) {
          // UserID matches – navigate to document details
          navigate(`/documentsDetails/${documentId}`);
        } else {
          // UserID doesn't match – show popup
          setShowPopup(true);
        }
      } catch (error) {
        console.error('Error parsing userData from localStorage:', error);
        setShowPopup(true);
      }
    } else {
      // No user data found – show popup
      console.warn("No user data found in localStorage.");
      setShowPopup(true);
    }
  }, [documentId, userId]);
  
  

  const handleConfirm = () => {
    setShowPopup(false);
    navigate(`/`); // Redirect to login with userId
  };

  return (
    <>
      {showPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-80 text-center">
            <h2 className="text-xl font-bold mb-4">Internal Access</h2>
            <p className="mb-4">You are identified as an internal user. Please log in to continue.</p>
            <button
              onClick={handleConfirm}
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
            >
              Go to Login
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default InternalUserPrompt;




