import React, { useState, useEffect } from "react";
import axios from "axios";
import { GETALLUSERS_API, createApproval } from "../../Constants/apiRoutes";
import { toast, ToastContainer } from "react-toastify";
const AddApprovalPopup = ({ isOpen, onClose, documentId }) => {
  const [activeTab, setActiveTab] = useState("search");
  const [searchText, setSearchText] = useState("");
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [selectedInternalUsers, setSelectedInternalUsers] = useState([]);
  const [selectedExternalUsers, setSelectedExternalUsers] = useState([]);
  const [manualName, setManualName] = useState("");
  const [manualEmail, setManualEmail] = useState("");
  const [externalUsers, setExternalUsers] = useState([]);
  const [isOpen1, setIsOpen1] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetchUsers();
      resetFields();
    }
  }, [isOpen]);

  const fetchUsers = async () => {
    const token = localStorage.getItem("token");
    try {
      const response = await axios.get(GETALLUSERS_API, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsers(response.data.users);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };
  const handleAddUser = () => {
    if (manualName && manualEmail) {
      setExternalUsers([
        ...externalUsers,
        { id: Date.now(), name: manualName, email: manualEmail },
      ]);
      setManualName("");
      setManualEmail("");
    }
  };
  const resetFields = () => {
    setSearchText("");
    setSelectedInternalUsers([]);
    setSelectedExternalUsers([]);
    setManualName("");
    setManualEmail("");
    setActiveTab("search");
  };

  useEffect(() => {
    if (searchText.trim() === "") {
      setFilteredUsers([]);
      return;
    }
    const query = searchText.toLowerCase();
    const filtered = users.filter(
      (user) =>
        (user.FirstName?.toLowerCase() || "").includes(query) ||
        (user.LastName?.toLowerCase() || "").includes(query) ||
        (user.Email?.toLowerCase() || "").includes(query)
    );

    setFilteredUsers(filtered);
  }, [searchText, users]);

  const handleSelectUser = (user) => {
    if (!selectedInternalUsers.some((u) => u.UserID === user.UserID)) {
      setSelectedInternalUsers([...selectedInternalUsers, user]);
    }
    setSearchText(""); // Clear search text after selecting a user
    setFilteredUsers([]); // Hide dropdown after selection
  };

  const handleRemoveUser = (id) => {
    setExternalUsers((prevUsers) => prevUsers.filter((user) => user.id !== id));
  };

  const handleSendMail = async () => {
    if (selectedInternalUsers.length === 0 && externalUsers.length === 0) {
      toast.warning("Please select at least one user!");
      return;
    }

    const token = localStorage.getItem("token");
    const tenantId = localStorage.getItem("TenantID");

    const payload = {
      documentId: documentId,
      approvalLevel: 1,
      status: "pending",
      comments: "Approval Request",
      tenantId: Number(tenantId),
      users: [
        // ...selectedInternalUsers.map((user) => ({
        //   UserID: user.UserID,            // assuming UserID exists
        //   FirstName: user.FirstName,
        //   Email: user.Email,
        //   IsInternal: true,
        // })),
        ...selectedInternalUsers.map((user) => user.UserID), // Only IDs
        ...externalUsers.map((user) => ({
          FirstName: user.name,
          Email: user.email,
          IsInternal: false,
        })),
      ],
    };

    try {
      const response = await axios.post(createApproval, payload, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      toast.success("Mail sent successfully!");
      onClose();
    } catch (error) {
      console.error("Error sending mail:", error);
      toast.error("Failed to send mail.");
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-2xl h-[60%] flex flex-col">
        <h2 className="text-lg font-semibold mb-4">Add Approval</h2>

        <div className="flex border-b mb-4">
          <button
            className={`flex-1 py-2 text-center ${
              activeTab === "search"
                ? "border-b-2 border-[#8B4513] text-[#8B4513] font-semibold"
                : "text-gray-500"
            }`}
            onClick={() => setActiveTab("search")}
          >
            Internal User
          </button>
          <button
            className={`flex-1 py-2 text-center ${
              activeTab === "manual"
                ? "border-b-2 border-[#8B4513] text-[#8B4513] font-semibold"
                : "text-gray-500"
            }`}
            onClick={() => setActiveTab("manual")}
          >
            External User
          </button>
        </div>

        <div className="flex-grow overflow-y-auto">
          {activeTab === "search" ? (
            <>
              {/* Selected Users Display */}
              {selectedInternalUsers.length > 0 && (
                <div className="mb-2 flex flex-wrap gap-2">
                  {selectedInternalUsers.map((user) => (
                    <span
                      key={user.UserID}
                      className="flex items-center px-2 py-1 bg-gray-200 rounded-md text-sm"
                    >
                      {user.FirstName} {user.LastName}
                      <button
                        onClick={() => handleRemoveUser(user.UserID)}
                        className="ml-2 text-red-500"
                      >
                        ✕
                      </button>
                    </span>
                  ))}
                </div>
              )}

              {/* Search Bar */}
              <input
                type="text"
                placeholder="Search by name or email..."
                className="w-full p-2 border rounded mb-4"
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
              />

              {/* Search Results */}
              {searchText.trim() !== "" && filteredUsers.length > 0 && (
                <div className="max-h-40 overflow-y-auto border rounded mb-4">
                  {filteredUsers.map((user) => (
                    <div
                      key={user.UserID}
                      className="p-2 cursor-pointer hover:bg-gray-100"
                      onClick={() => handleSelectUser(user)}
                    >
                      <p className="text-sm font-medium">
                        {user.FirstName} {user.LastName}
                      </p>
                      <p className="text-xs text-gray-500">{user.Email}</p>
                    </div>
                  ))}
                </div>
              )}
            </>
          ) : (
            <div>
              {/* Input Fields */}
              <input
                type="text"
                placeholder="Enter name..."
                className="w-full p-2 border rounded mb-2"
                value={manualName}
                onChange={(e) => setManualName(e.target.value)}
              />
              <input
                type="email"
                placeholder="Enter email..."
                className="w-full p-2 border rounded mb-2"
                value={manualEmail}
                onChange={(e) => setManualEmail(e.target.value)}
              />
              <button
                onClick={handleAddUser}
                className="w-full bg-[#8B4513] text-white py-2 rounded"
              >
                Add External User
              </button>

              {/* Display Added Users */}
              <div className="mt-4 flex flex-wrap gap-2">
                {externalUsers.map((user) => (
                  <span
                    key={user.id}
                    className="flex items-center px-2 py-1 bg-gray-200 rounded-md text-sm"
                  >
                    {user.name} ({user.email})
                    <button
                      onClick={() => handleRemoveUser(user.id)}
                      className="ml-2 text-red-500"
                    >
                      ✕
                    </button>
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="flex justify-end space-x-4 mt-4 border-t pt-4">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#8B4513] text-white rounded"
          >
            Cancel
          </button>
          <button
            onClick={() => setIsOpen1(true)}
            className="px-4 py-2 bg-[#8B4513] text-white rounded"
          >
            Send Mail
          </button>
        </div>
        {isOpen1 && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-white p-6 rounded shadow-lg">
              <p className="text-lg font-semibold mb-4">
                Are you sure you want to send the mail?
              </p>
              <div className="flex justify-end space-x-4">
                <button
                  onClick={() => setIsOpen1(false)}
                  className="px-4 py-2 bg-[#8B4513] text-white rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSendMail}
                  className="px-4 py-2 bg-[#8B4513] text-white rounded"
                >
                  Confirm
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
export default AddApprovalPopup;
